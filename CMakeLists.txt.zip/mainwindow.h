#pragma once
#include <QMainWindow>
#include <QStackedWidget>
#include <QPushButton>
#include <QLabel>
#include <QSlider>
#include <QVector>

// ===== Enum cho trạng thái ô =====
enum Cell { Empty, Black, White, Block };

// ===== OthelloButton =====
class OthelloButton : public QPushButton
{
public:
    OthelloButton(QWidget *parent = nullptr);
    Cell cell;
    bool highlight;
    bool lastMove;
protected:
    void paintEvent(QPaintEvent *event) override;
};

// ===== MainWindow =====
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    // UI
    QStackedWidget *stack;
    QWidget *settingWidget, *gameWidget;
    QWidget *boardWidget;
    QLabel *lblStatus, *lblScore;
    QSlider *sliderSize, *sliderBlock;
    QPushButton *btnBlackFirst, *btnWhiteFirst, *btnRandomFirst;
    QPushButton *btnSettingOk, *btnSettingCancel, *btnBackMenu;

    // Game state
    int boardSize;
    int turnCount;
    int lastMoveRow, lastMoveCol;
    Cell currentPlayer;
    Cell settingFirst;
    QVector<QVector<Cell>> board;
    QVector<QVector<OthelloButton*>> buttons;

    // Methods
    void setupSetting();
    void setupGame();
    void buildBoardUI();
    void clearBoardUI();
    void updateBoardUI();
    void resetGame(int size, int block, Cell first);
    void showGameOver();
    void highlightValidMoves();

    // Game logic
    bool isValidMove(int row, int col, Cell player) const;
    void onCellClicked();
    void makeMove(int row, int col);
    void flipDiscs(int row, int col, Cell player);
    void nextPlayer();
    bool hasValidMove(Cell player) const;
    int countDiscs(Cell player) const;

private slots:
    void onSettingOk();
};
