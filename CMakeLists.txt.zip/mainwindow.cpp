#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QPainter>
#include <QSet>

// ===== OthelloButton Implementation =====
OthelloButton::OthelloButton(QWidget *parent)
    : QPushButton(parent), cell(Empty), highlight(false), lastMove(false)
{
    // set color for othello board
    setStyleSheet(R"(
        QPushButton {
            background-color: #e0e0e0; border: 1px solid #bdbdbd;
        }
        QPushButton:hover {
            background-color: #bbdefb;
        }
    )");
    setCursor(Qt::PointingHandCursor); // cursor: pointer
}

void OthelloButton::paintEvent(QPaintEvent *event)
{
    QPushButton::paintEvent(event);
    QPainter p(this);
    if (cell == Black || cell == White)
    {
        // to mau quan co
        QColor color = (cell == Black) ? Qt::black : Qt::white;
        p.setRenderHint(QPainter::Antialiasing, true);      // cho phep su dung toan tu 3 ngoi
        p.setBrush(color);
        p.setPen(Qt::NoPen);
        int margin = width() / 8;
        p.drawEllipse(margin, margin, width() - 2 * margin, height() - 2 * margin);
    }
    if (cell == Block)
    {
        // colored block with blue
        p.setBrush(QColor("#1976d2"));
        p.setPen(Qt::NoPen);
        int margin = width() / 8;
        p.drawRect(margin, margin, width() - 2 * margin, height() - 2 * margin);
    }
    if (highlight)
    {
        // highlight available next step with green
        QPen pen(Qt::green, 3);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawRect(rect().adjusted(2, 2, -2, -2));
    }
    if (lastMove)
    {
        // colored last move with round blue
        QPen pen(QColor("#1976d2"), 3);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(rect().adjusted(6, 6, -6, -6));
    }
}

// ===== MainWindow =====
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    stack(new QStackedWidget(this)),    // container for all screens
    boardSize(8),                       // default board size
    currentPlayer(Black),               // black is default player
    turnCount(0),                       // now is 0 no move yet
    lastMoveRow(-1),
    lastMoveCol(-1)
{
    setWindowTitle("Othello");            // <title>Othello</title>
    setMinimumSize(1024, 700);            // body { min-width: 1024px; min-height: 700px; }
    setCentralWidget(stack);              // set stack is main content

    setupSetting();                       // setting screen
    setupGame();                          // build game

    stack->setCurrentWidget(settingWidget); // show setting screen by default
}


MainWindow::~MainWindow() {}

// ===== GAME SETTING UI =====
void MainWindow::setupSetting()
{
    settingWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(settingWidget);
    layout->setAlignment(Qt::AlignCenter);

    // change to h1 then font-size: 36px; font-weight: bold; text-allign: center
    QLabel *title = new QLabel("Othello\n\nGame Settings", this);
    QFont titleFont;
    titleFont.setPointSize(36);
    titleFont.setBold(true);
    title->setFont(titleFont);
    title->setAlignment(Qt::AlignCenter);

    // Board size
    QHBoxLayout *sizeLayout = new QHBoxLayout;
    QLabel *lblSize = new QLabel("Board Size:", this);
    QFont labelFont;
    // label font-size: 20px; min-width:120px;
    labelFont.setPointSize(20);
    lblSize->setFont(labelFont);
    lblSize->setMinimumWidth(120);
    // input type="number" min=6 max=12 step=2 default=8
    sliderSize = new QSlider(Qt::Horizontal, this);
    sliderSize->setRange(6, 12);
    sliderSize->setSingleStep(2);
    sliderSize->setTickInterval(2);
    sliderSize->setTickPosition(QSlider::TicksBelow);
    sliderSize->setValue(8);
    // default value of input
    QLabel *sizeValue = new QLabel("8", this);
    sizeValue->setMinimumWidth(32);
    sizeValue->setFont(labelFont);
    // update and render new value
    connect(sliderSize, &QSlider::valueChanged, [this, sizeValue](int v){
        if (v % 2 != 0) v += 1;
        this->sliderSize->setValue(v);
        sizeValue->setText(QString::number(v));
        this->sliderBlock->setMaximum(v*v/2 - 4);
    });
    sizeLayout->addWidget(lblSize);
    sizeLayout->addWidget(sliderSize, 1);
    sizeLayout->addWidget(sizeValue);

    // Block count
    QHBoxLayout *blockLayout = new QHBoxLayout;
    QLabel *lblBlock = new QLabel("Blocks:", this);
    lblBlock->setFont(labelFont);
    lblBlock->setMinimumWidth(120);
    sliderBlock = new QSlider(Qt::Horizontal, this);
    sliderBlock->setRange(0, 16);
    sliderBlock->setValue(0);
    QLabel *blockValue = new QLabel("0", this);
    blockValue->setMinimumWidth(32);
    blockValue->setFont(labelFont);
    connect(sliderBlock, &QSlider::valueChanged, [blockValue](int v){ blockValue->setText(QString::number(v)); });
    blockLayout->addWidget(lblBlock);
    blockLayout->addWidget(sliderBlock, 1);
    blockLayout->addWidget(blockValue);

    // First player buttons
    QHBoxLayout *firstLayout = new QHBoxLayout;
    btnBlackFirst = new QPushButton("Black First", this);
    btnWhiteFirst = new QPushButton("White First", this);
    btnRandomFirst = new QPushButton("Random First", this);

    // style for each btn
    for (auto btn : {btnBlackFirst, btnWhiteFirst, btnRandomFirst}) {
        btn->setStyleSheet("font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color: #757575; color:white");
        btn->setCheckable(true);
        btn->setMinimumWidth(180);
    }
    btnBlackFirst->setChecked(true); settingFirst = Black;      // default value is black
    connect(btnBlackFirst, &QPushButton::clicked, [this]{
        // set checked value to true and another to false
        btnBlackFirst->setChecked(true); btnWhiteFirst->setChecked(false); btnRandomFirst->setChecked(false); settingFirst = Black;
        // change active style to clicked btn
        for (auto btn : {btnBlackFirst, btnWhiteFirst, btnRandomFirst}) {
            btn->setStyleSheet("font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color: #757575; color:white");
        }
        btnBlackFirst->setStyleSheet("font-weight:bold; font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color:white; color:#757575");
    });
    connect(btnWhiteFirst, &QPushButton::clicked, [this]{
        // set checked value to true and another to false
        btnBlackFirst->setChecked(false); btnWhiteFirst->setChecked(true); btnRandomFirst->setChecked(false); settingFirst = White;
        // change active style to clicked btn
        for (auto btn : {btnBlackFirst, btnWhiteFirst, btnRandomFirst}) {
            btn->setStyleSheet("font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color: #757575; color:white");
        }
        btnWhiteFirst->setStyleSheet("font-weight:bold; font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color:white; color:#757575");
    });
    connect(btnRandomFirst, &QPushButton::clicked, [this]{
        // set checked value to true and another to false
        btnBlackFirst->setChecked(false); btnWhiteFirst->setChecked(false); btnRandomFirst->setChecked(true);
        // change active style to clicked btn
        settingFirst = (QRandomGenerator::global()->bounded(2) ? Black : White);
        for (auto btn : {btnBlackFirst, btnWhiteFirst, btnRandomFirst}) {
            btn->setStyleSheet("font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color: #757575; color:white");
        }
        btnRandomFirst->setStyleSheet("font-weight:bold; font-size: 24px; border-radius: 12px; padding: 12px 36px; background-color:white; color:#757575");
    });

    // ___ Black ___ White ___ Random ___
    firstLayout->addStretch(1);
    firstLayout->addWidget(btnBlackFirst);
    firstLayout->addStretch(1);
    firstLayout->addWidget(btnWhiteFirst);
    firstLayout->addStretch(1);
    firstLayout->addWidget(btnRandomFirst);
    firstLayout->addStretch(1);

    // ok and exit btn
    QHBoxLayout *okCancelLayout = new QHBoxLayout;
    btnSettingOk = new QPushButton("Start Game", this);
    btnSettingCancel = new QPushButton("Exit Game", this);
    for (auto btn : {btnSettingOk, btnSettingCancel}) {
        btn->setStyleSheet("font-size: 25px; padding: 12px 46px; color: #757575; font-weight:bold");
        btn->setMinimumWidth(120);
    }

    // ______ Start Game __ Exit Game ______
    okCancelLayout->addStretch(3);
    okCancelLayout->addWidget(btnSettingOk);
    okCancelLayout->addStretch(1);
    okCancelLayout->addWidget(btnSettingCancel);
    okCancelLayout->addStretch(3);

    // vertical layout
    layout->addStretch(2);
    layout->addWidget(title, 0, Qt::AlignHCenter);
    layout->addSpacing(32);
    layout->addLayout(sizeLayout);
    layout->addSpacing(24);
    layout->addLayout(blockLayout);
    layout->addSpacing(36);
    layout->addLayout(firstLayout);
    layout->addSpacing(36);
    layout->addLayout(okCancelLayout);
    layout->addStretch(3);

    connect(btnSettingOk, &QPushButton::clicked, this, &MainWindow::onSettingOk);
    connect(btnSettingCancel, &QPushButton::clicked, this, [this]{ close(); });

    stack->addWidget(settingWidget);
}

// ===== GAME UI =====
void MainWindow::setupGame()
{
    gameWidget = new QWidget(this);
    gameWidget->setStyleSheet("background:#f5f5f5;");

    QVBoxLayout *mainVLayout = new QVBoxLayout(gameWidget);
    mainVLayout->setContentsMargins(0, 0, 0, 0);
    mainVLayout->setSpacing(0);
    mainVLayout->addStretch(1);

    QWidget *centerWidget = new QWidget(this);
    QHBoxLayout *centerHLayout = new QHBoxLayout(centerWidget);
    centerHLayout->setContentsMargins(0, 0, 0, 0);
    centerHLayout->setSpacing(48);
    centerHLayout->addStretch(1);

    int maxBoardPixel = 520;
    int cellSize = maxBoardPixel / boardSize;
    int boardPixel = cellSize * boardSize;
    boardWidget = new QWidget(this);
    boardWidget->setFixedSize(boardPixel, boardPixel);
    centerHLayout->addWidget(boardWidget, 0, Qt::AlignCenter);

    QWidget *infoWidget = new QWidget(this);
    QVBoxLayout *infoLayout = new QVBoxLayout(infoWidget);
    infoLayout->setContentsMargins(0, 0, 0, 0);
    infoLayout->setSpacing(24);
    lblStatus = new QLabel("Turn: Black", this);
    lblScore = new QLabel("Black: 0\nWhite: 0", this);
    QFont statusFont;
    statusFont.setPointSize(28);
    statusFont.setBold(true);
    lblStatus->setFont(statusFont);
    lblScore->setFont(statusFont);
    lblStatus->setAlignment(Qt::AlignLeft | Qt::AlignTop);
    lblScore->setAlignment(Qt::AlignLeft | Qt::AlignTop);
    infoLayout->addWidget(lblStatus);
    infoLayout->addWidget(lblScore);
    infoLayout->addStretch();
    infoWidget->setFixedWidth(220);
    centerHLayout->addWidget(infoWidget, 0, Qt::AlignVCenter);
    centerHLayout->addStretch(1);

    mainVLayout->addWidget(centerWidget, 0, Qt::AlignCenter);
    mainVLayout->addStretch(1);

    QWidget *btnWidget = new QWidget(this);
    QHBoxLayout *btnLayout = new QHBoxLayout(btnWidget);
    btnLayout->setContentsMargins(0, 0, 0, 0);
    btnLayout->setSpacing(40);
    btnLayout->setAlignment(Qt::AlignHCenter);
    btnBackMenu = new QPushButton("Back to Menu", this);
    btnBackMenu->setStyleSheet("background:#222; color:white; border-radius:16px; font-size:24px; padding:12px 40px;");
    btnLayout->addWidget(btnBackMenu);
    btnWidget->setFixedHeight(70);
    mainVLayout->addSpacing(30);
    mainVLayout->addWidget(btnWidget, 0, Qt::AlignHCenter);
    mainVLayout->addStretch(1);

    connect(btnBackMenu, &QPushButton::clicked, this, [this]{ stack->setCurrentWidget(settingWidget); });

    stack->addWidget(gameWidget);
}

// ===== BOARD UI =====
void MainWindow::buildBoardUI()
{
    clearBoardUI();

    int cellSize = boardWidget->width() / boardSize;
    QGridLayout *grid = new QGridLayout(boardWidget);
    grid->setSpacing(2);
    grid->setContentsMargins(0, 0, 0, 0);

    buttons.resize(boardSize);
    for (int r = 0; r < boardSize; ++r)
    {
        buttons[r].resize(boardSize);
        for (int c = 0; c < boardSize; ++c)
        {
            OthelloButton *btn = new OthelloButton(this);
            btn->setFixedSize(cellSize, cellSize);
            grid->addWidget(btn, r, c);
            buttons[r][c] = btn;
            btn->setProperty("row", r);
            btn->setProperty("col", c);
            connect(btn, &QPushButton::clicked, this, &MainWindow::onCellClicked);
        }
    }
    boardWidget->setLayout(grid);

    // Khởi tạo bàn cờ logic
    board.resize(boardSize);
    for (int r = 0; r < boardSize; ++r)
        board[r].resize(boardSize, Empty);

    // Đặt 4 quân cờ giữa bàn
    int mid = boardSize / 2;
    board[mid - 1][mid - 1] = White;
    board[mid][mid] = White;
    board[mid - 1][mid] = Black;
    board[mid][mid - 1] = Black;

    // Sinh block
    int blockCount = sliderBlock ? sliderBlock->value() : 0;
    QSet<QPair<int, int>> used;
    used << qMakePair(mid - 1, mid - 1) << qMakePair(mid, mid)
         << qMakePair(mid - 1, mid) << qMakePair(mid, mid - 1);
    int placed = 0;
    while (placed < blockCount)
    {
        int r = QRandomGenerator::global()->bounded(boardSize);
        int c = QRandomGenerator::global()->bounded(boardSize);
        if (board[r][c] == Empty && !used.contains(qMakePair(r, c)))
        {
            board[r][c] = Block;
            used << qMakePair(r, c);
            placed++;
        }
    }
}

void MainWindow::clearBoardUI()
{
    if (!boardWidget)
        return;
    QLayout *layout = boardWidget->layout();
    if (layout)
    {
        QLayoutItem *item;
        while ((item = layout->takeAt(0)) != nullptr)
        {
            delete item->widget();
            delete item;
        }
        delete layout;
    }
    buttons.clear();
}

void MainWindow::updateBoardUI()
{
    for (int r = 0; r < boardSize; ++r)
    {
        for (int c = 0; c < boardSize; ++c)
        {
            OthelloButton *btn = static_cast<OthelloButton *>(buttons[r][c]);
            btn->cell = board[r][c];
            btn->highlight = false;
            btn->lastMove = (r == lastMoveRow && c == lastMoveCol);
            btn->update();
        }
    }
    highlightValidMoves();

    // Sửa lại phần điểm: mỗi dòng 1 bên, không bị dính chữ
    int black = countDiscs(Black);
    int white = countDiscs(White);
    lblStatus->setText(
        QString("<span style='color:%1; font-weight:bold;'>Turn: %2</span>")
            .arg((currentPlayer == Black) ? "black" : "#222")
            .arg((currentPlayer == Black) ? "Black" : "White"));
    lblScore->setText(
        QString("Black: %1\nWhite: %2").arg(black).arg(white));
}

// ===== GAME LOGIC =====
bool MainWindow::isValidMove(int row, int col, Cell player) const
{
    if (board[row][col] != Empty)
        return false;
    Cell opponent = (player == Black) ? White : Black;
    static const int dr[] = {-1, -1, -1, 0, 0, 1, 1, 1};
    static const int dc[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    for (int d = 0; d < 8; ++d)
    {
        int r = row + dr[d], c = col + dc[d], cnt = 0;
        while (r >= 0 && r < boardSize && c >= 0 && c < boardSize &&
               board[r][c] == opponent)
        {
            r += dr[d];
            c += dc[d];
            ++cnt;
        }
        if (cnt > 0 && r >= 0 && r < boardSize && c >= 0 && c < boardSize &&
            board[r][c] == player)
        {
            int rr = row + dr[d], cc = col + dc[d];
            bool blockFound = false;
            for (int i = 0; i < cnt; ++i)
            {
                if (board[rr][cc] == Block)
                {
                    blockFound = true;
                    break;
                }
                rr += dr[d];
                cc += dc[d];
            }
            if (!blockFound)
                return true;
        }
    }
    return false;
}

void MainWindow::onCellClicked()
{
    QPushButton *btn = qobject_cast<QPushButton *>(sender());
    int row = btn->property("row").toInt();
    int col = btn->property("col").toInt();
    if (!isValidMove(row, col, currentPlayer))
        return;
    makeMove(row, col);
    updateBoardUI();
}

void MainWindow::makeMove(int row, int col)
{
    board[row][col] = currentPlayer;
    flipDiscs(row, col, currentPlayer);
    lastMoveRow = row;
    lastMoveCol = col;
    ++turnCount;
    nextPlayer();
}

void MainWindow::flipDiscs(int row, int col, Cell player)
{
    Cell opponent = (player == Black) ? White : Black;
    static const int dr[] = {-1, -1, -1, 0, 0, 1, 1, 1};
    static const int dc[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    for (int d = 0; d < 8; ++d)
    {
        int r = row + dr[d], c = col + dc[d], cnt = 0;
        while (r >= 0 && r < boardSize && c >= 0 && c < boardSize &&
               board[r][c] == opponent)
        {
            r += dr[d];
            c += dc[d];
            ++cnt;
        }
        if (cnt > 0 && r >= 0 && r < boardSize && c >= 0 && c < boardSize &&
            board[r][c] == player)
        {
            int rr = row + dr[d], cc = col + dc[d];
            bool blockFound = false;
            for (int i = 0; i < cnt; ++i)
            {
                if (board[rr][cc] == Block)
                {
                    blockFound = true;
                    break;
                }
                rr += dr[d];
                cc += dc[d];
            }
            if (!blockFound)
            {
                rr = row + dr[d];
                cc = col + dc[d];
                for (int i = 0; i < cnt; ++i)
                {
                    board[rr][cc] = player;
                    rr += dr[d];
                    cc += dc[d];
                }
            }
        }
    }
}

void MainWindow::nextPlayer()
{
    currentPlayer = (currentPlayer == Black) ? White : Black;
    if (!hasValidMove(currentPlayer))
    {
        currentPlayer = (currentPlayer == Black) ? White : Black;
        if (!hasValidMove(currentPlayer))
        {
            showGameOver();
        }
    }
}

bool MainWindow::hasValidMove(Cell player) const
{
    for (int r = 0; r < boardSize; ++r)
        for (int c = 0; c < boardSize; ++c)
            if (isValidMove(r, c, player))
                return true;
    return false;
}

int MainWindow::countDiscs(Cell player) const
{
    int cnt = 0;
    for (int r = 0; r < boardSize; ++r)
        for (int c = 0; c < boardSize; ++c)
            if (board[r][c] == player)
                ++cnt;
    return cnt;
}

void MainWindow::resetGame(int size, int block, Cell first)
{
    boardSize = size;
    currentPlayer = first;
    turnCount = 0;
    lastMoveRow = lastMoveCol = -1;
    clearBoardUI();
    setupGame();
    buildBoardUI();
    updateBoardUI();
    stack->setCurrentWidget(gameWidget);
}

void MainWindow::showGameOver()
{
    int black = countDiscs(Black);
    int white = countDiscs(White);
    QString msg;
    if (black > white)
        msg = "Black wins!";
    else if (white > black)
        msg = "White wins!";
    else
        msg = "Draw!";
    auto reply = QMessageBox::question(this, "Game Over",
                                       QString("Black: %1\nWhite: %2\n%3\n\nNew Game?").arg(black).arg(white).arg(msg),
                                       QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes)
        stack->setCurrentWidget(settingWidget);
}

void MainWindow::highlightValidMoves()
{
    for (int r = 0; r < boardSize; ++r)
        for (int c = 0; c < boardSize; ++c)
            if (isValidMove(r, c, currentPlayer))
                static_cast<OthelloButton *>(buttons[r][c])->highlight = true;
}

// ===== SLOTS =====
void MainWindow::onSettingOk()
{
    int size = sliderSize->value();
    int block = sliderBlock->value();
    Cell first = settingFirst;
    resetGame(size, block, first);
}
